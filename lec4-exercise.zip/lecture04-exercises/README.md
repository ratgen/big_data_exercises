# Lecture 4 exercises

Alot of inspiration from: 
* https://github.com/jakobhviid/DataScienceCourseSDU

# Pyspark BDE docker image issue:
The docker image from https://github.com/big-data-europe/docker-spark has an issue, and therefore the folder "clusterPysparkFixed" has a fix for the Python usage for now.
This means that localPyspark and sentimentExercise folder does not work at the moment. However, the folders have been preserved in hopes that the original Docker image will receive a fix.
Discussion at: https://github.com/big-data-europe/docker-spark/issues/139